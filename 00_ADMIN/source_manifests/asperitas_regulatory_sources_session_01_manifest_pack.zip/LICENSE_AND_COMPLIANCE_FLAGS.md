# License / Compliance Red Flags — Session 01

## Immediate red flags
- Species+ website and Species+/CITES Checklist API: use is subject to Terms & Conditions. Commercial use may require prior written permission.
- CITES Trade Database: official guide permits reuse with attribution, but interpretation requires care; actual-trade vs permits-issued ambiguity must be preserved.
- IRIS/NRI: may contain login-only workflows and personal information fields. Do not scrape personal data.
- K-BDS: dataset-level access, embargo, domestic researcher restrictions, and individual dataset licenses must be checked.
- ABSCH/CBD: country ABS profiles may include legal obligations; do not treat summaries as legal advice.
- LMO/BCH: use latest Korean law/고시/민원서식 before operational compliance decisions.

## Asperitas rule
Nothing from this session becomes production compliance advice until:
1. raw source preserved,
2. latest version checked,
3. license status reviewed,
4. legal/regulatory owner signs off,
5. decision log created.
