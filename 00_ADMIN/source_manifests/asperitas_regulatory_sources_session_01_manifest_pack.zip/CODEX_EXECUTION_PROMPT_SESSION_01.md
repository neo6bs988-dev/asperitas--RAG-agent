# Codex Execution Prompt — Regulatory Source Collection Session 01

You are building the Asperitas regulatory/government raw source layer.

Input file:
- source_manifest_session_01_45_sources.csv

Task:
1. Create the exact target folders listed in the manifest.
2. For each row:
   - Fetch the URL if publicly accessible.
   - Preserve raw file if PDF/HWP/HWPX/ZIP/DOCX/XLSX.
   - For HTML, save:
     a) raw HTML,
     b) extracted text as Markdown,
     c) metadata JSON.
   - For dynamic/login pages, save metadata only and mark `manual_required=true`.
3. Create metadata JSON for every source:
   - id
   - title
   - category
   - source_url
   - target_folder
   - downloaded_at
   - access_date
   - file_type
   - source_owner
   - license_status: unknown / public / restricted / requires_review
   - commercial_use_status
   - notes
   - checksum_sha256
4. Do not bypass login, robots, paywalls, or access restrictions.
5. Do not store personal data from NRI/IRIS service forms.
6. Build a final `collection_report.md` listing:
   - success
   - failed
   - manual required
   - license review required
   - next crawl candidates

Output expected:
- 01_RAW_SOURCES/P4_REGULATORY_GOVERNMENT/... populated
- 00_ADMIN/file_inventory.csv
- 00_ADMIN/license_review_queue.csv
- 00_ADMIN/collection_report_session_01.md
