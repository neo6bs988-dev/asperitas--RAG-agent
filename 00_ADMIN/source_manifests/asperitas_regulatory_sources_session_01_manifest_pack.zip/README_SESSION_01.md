# Asperitas Regulatory/Government Source Collection — Session 01

생성일: 2026-06-09 16:43:35
범위: 사용자가 지정한 P4_REGULATORY_GOVERNMENT 계층
수집 수량: 45개 소스 포인터/원문 후보

## 목적
이 패키지는 Codex 또는 사내 수집 스크립트가 원문을 다운로드·정리·메타데이터화하기 위한 1차 매니페스트입니다.

## 폴더 매핑
- `연구과제.hwpx` → `01_RAW_SOURCES/P4_REGULATORY_GOVERNMENT/KOREA_RND_GRANTS/`
- CITES 자료 → `01_RAW_SOURCES/P4_REGULATORY_GOVERNMENT/CITES/`
- Nagoya/CBD 자료 → `01_RAW_SOURCES/P4_REGULATORY_GOVERNMENT/NAGOYA_CBD/`
- LMO/Cartagena 자료 → `01_RAW_SOURCES/P4_REGULATORY_GOVERNMENT/LMO_BIOSAFETY/`
- IRIS/NRI/K-BDS 자료 → `01_RAW_SOURCES/P4_REGULATORY_GOVERNMENT/K_BDS_IRIS_NRI/`
- BioIN 합성생물학 collection → `01_RAW_SOURCES/P4_REGULATORY_GOVERNMENT/BIOIN_KOREA_SYNBIO/`

## 절대 규칙
1. 원문 파일은 반드시 출처 URL, 접근일, 다운로드일, 라이선스/이용약관 상태를 메타데이터에 남긴다.
2. Species+ / API / Checklist 등은 상업적 사용 제한 가능성이 있으므로 production DB ingest 전 법무/라이선스 검토를 거친다.
3. 정부 R&D/IRIS/K-BDS/LMO 자료는 최신 공고와 첨부파일 버전이 중요하므로 파일명에 공고번호·날짜·다운로드일을 붙인다.
4. HTML은 원문 HTML, 추출 텍스트 Markdown, 스크린샷/PDF 변환본을 분리 저장한다.
5. 개인정보 입력이 필요한 서비스 페이지는 실제 개인정보를 저장하지 않는다.

## 다음 세션 추천
- Session 02: CITES 한국 행정서식/WIMS/관세청/국립생물자원관 중심 15~30개 추가
- Session 03: Nagoya/CBD 국가별 ABS law profile 30개 추가
- Session 04: LMO법/통합고시/연구시설/수입신고 서식 20개 추가
- Session 05: BioIN 하위 보고서/동향/보도자료 recursive 수집
