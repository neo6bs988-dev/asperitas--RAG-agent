# Asperitas Agent Source Collection Manifest

Generated: 2026-06-09 UTC

This package is designed for pre-Codex source collection before building an Asperitas company agent.
It contains 450 registry rows, including 420 external/public source targets and 30 internal file placeholders.

## Critical rule
Do not bulk-ingest copyrighted, paywalled, restricted, or database-licensed full text/data until the source-specific terms of use and license are checked.
For papers, ingest metadata first, then download open-access full text only when permitted.
For internal company documents, create redacted copies before sending to external tools.

## Recommended sequence
1. Create the folder structure from `Folder_Map`.
2. Put AOS v10/v9/v8 and the latest active prompt in `P0_ACTIVE_AOS`.
3. Verify URLs and license/terms for each public source.
4. Create `metadata.csv` and `file_inventory.xlsx` using `Source_Registry`.
5. Chunk only after source_id, priority, disclosure, license_status, and provenance are attached.
6. Build vector DB / knowledge graph / eval suite only after metadata and compliance checks.
7. Start with four MVP agents: COO Execution, Compliance Gatekeeper, R&D Design, IR/Fundraising.

## Files
- `asperitas_agent_source_registry_400plus.xlsx`: formatted Excel workbook.
- `asperitas_agent_source_registry_400plus.csv`: raw source registry for scripts.
- `README_asperitas_source_collection.md`: this guide.
